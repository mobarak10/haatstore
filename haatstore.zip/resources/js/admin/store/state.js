export default {
    activeCategories: [],
    activeProducts: [],
    cartProducts: [],
    cartSubTotal: null,
    productFilter: {}
}

