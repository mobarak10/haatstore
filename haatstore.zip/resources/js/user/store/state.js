export default {
    activeCategories: [],
    activeProducts: [],
    cartProducts: [],
    cartSubTotal: null,
    cartPurchaseTotal: null,
    productFilter: {},
    filteredProductsFromServer: [], // fetch from server,
    productsIsLoading: false,
    temp:{ // temp state
        searchProduct: null, // current value of search product
    }
};
