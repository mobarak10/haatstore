<?php

return [
    'hello' => 'Hello World!',
    'laravel' => 'Laravel',
    'login' => 'Login',
    'register' => 'Register',

];
