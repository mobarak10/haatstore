<!-- right bar -->
<div class="right-bar">
    <div class="title">
        <span title="Settings">Settings</span>
        <a href="#" class="settings">
            <i class="fa fa-times"></i>
        </a>
    </div>

    <nav class="aside-nav overlay-scrollbar">
        {{-- shop --}}
        <li id="settings">
            <a href="#" title="setup">
                <i class="fa fa-cog" aria-hidden="true"></i>
                Setting
            </a>
        </li>
    </nav>
</div>
<!-- right bar -->
