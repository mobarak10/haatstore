<!-- right bar -->
<div class="right-bar">
    <div class="title">
        <span title="Settings">Settings</span>
        <a href="#" class="settings">
            <i class="fa fa-times"></i>
        </a>
    </div>

    <div class="settings-body">
        <div class="nicescroll-box">
            <div class="wrap">

            </div>
        </div>
    </div>
</div>
<!-- right bar -->
