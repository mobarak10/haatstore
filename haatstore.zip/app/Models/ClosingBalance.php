<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClosingBalance extends Model
{
    protected $guarded = [];
}
